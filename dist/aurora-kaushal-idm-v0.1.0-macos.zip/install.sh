#!/usr/bin/env bash
set -e
echo "Installing AURORA Kaushal IDM to /Applications..."
killall -9 aurora-gui 2>/dev/null || true
rm -rf "/Applications/AURORA Kaushal IDM.app"
cp -R "AURORA Kaushal IDM.app" "/Applications/"
echo "✅ AURORA Kaushal IDM installed to /Applications!"
