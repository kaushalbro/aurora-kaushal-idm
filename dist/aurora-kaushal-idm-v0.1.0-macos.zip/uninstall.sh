#!/usr/bin/env bash
set -e
echo "Uninstalling AURORA Kaushal IDM..."
killall -9 aurora-gui 2>/dev/null || true
rm -rf "/Applications/AURORA Kaushal IDM.app"
rm -rf ~/Library/Application\ Support/aurora 2>/dev/null || true
echo "✅ AURORA Kaushal IDM removed."
