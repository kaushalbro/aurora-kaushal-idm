#!/usr/bin/env bash
set -e
echo "Uninstalling AURORA IDM..."
killall -9 aurora-gui 2>/dev/null || true
rm -rf "/Applications/AURORA IDM.app" "/Applications/AURORA Kaushal IDM.app"
rm -rf ~/Library/Application\ Support/aurora 2>/dev/null || true
echo "✅ AURORA IDM removed."
