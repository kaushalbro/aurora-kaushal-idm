@echo off
echo ========================================================
echo  AURORA Kaushal IDM - Windows Clean Installer
echo ========================================================
echo [1/3] Terminating existing running instances...
taskkill /F /IM aurora-gui.exe 2>nul
timeout /t 1 /nobreak >nul

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\AuroraIDM"
echo [2/3] Cleaning previous installation at %INSTALL_DIR%...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
mkdir "%INSTALL_DIR%"

copy /y "%~dp0aurora-gui.exe" "%INSTALL_DIR%\" >nul
copy /y "%~dp0icon.png" "%INSTALL_DIR%\" >nul 2>nul
copy /y "%~dp0uninstall.bat" "%INSTALL_DIR%\" >nul

echo [3/3] Creating Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'AURORA Kaushal IDM.lnk')); $s.TargetPath = '%INSTALL_DIR%\aurora-gui.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.Save()"

echo.
echo ========================================================
echo  SUCCESS: AURORA Kaushal IDM is installed and ready!
echo ========================================================
pause
