@echo off
title AURORA Kaushal IDM Uninstaller
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\AuroraIDM"

echo ========================================================
echo  AURORA Kaushal IDM - Uninstaller
echo ========================================================
echo [1/2] Terminating running aurora-gui.exe instances...
taskkill /F /IM aurora-gui.exe 2>nul
timeout /t 1 /nobreak >nul

echo [2/2] Deleting application files, cache, and shortcuts...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
del /f /q "%USERPROFILE%\Desktop\AURORA Kaushal IDM.lnk" 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\AURORA Kaushal IDM" 2>nul

echo.
echo ========================================================
echo  AURORA Kaushal IDM has been completely removed.
echo ========================================================
pause
