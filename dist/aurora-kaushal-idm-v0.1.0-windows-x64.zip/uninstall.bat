@echo off
echo ========================================================
echo  AURORA Kaushal IDM - Windows Uninstaller
echo ========================================================
echo [1/2] Terminating running aurora-gui.exe instances...
taskkill /F /IM aurora-gui.exe 2>nul
timeout /t 1 /nobreak >nul

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\AuroraIDM"
echo [2/2] Deleting installation files and shortcuts...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
del /f /q "%USERPROFILE%\Desktop\AURORA Kaushal IDM.lnk" 2>nul
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\AURORA Kaushal IDM.lnk" 2>nul

echo.
echo ========================================================
echo  AURORA Kaushal IDM has been completely removed.
echo ========================================================
pause
