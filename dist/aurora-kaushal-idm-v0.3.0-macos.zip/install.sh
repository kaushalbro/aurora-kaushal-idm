#!/usr/bin/env bash
set -e
echo "Installing AURORA IDM to /Applications..."
killall -9 aurora-desktop 2>/dev/null || true
killall -9 aurora-gui 2>/dev/null || true
rm -rf "/Applications/AURORA IDM.app" "/Applications/AURORA Kaushal IDM.app"
cp -R "AURORA IDM.app" "/Applications/"
echo "✅ AURORA IDM installed to /Applications!"
