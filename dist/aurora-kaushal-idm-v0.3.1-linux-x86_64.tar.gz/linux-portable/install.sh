#!/usr/bin/env bash
set -e
echo "Installing AURORA IDM to ~/.local/bin..."
killall -9 aurora-desktop 2>/dev/null || true
killall -9 aurora-gui 2>/dev/null || true

mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications
mkdir -p ~/.local/share/icons/hicolor/512x512/apps
mkdir -p ~/.local/share/pixmaps

cp aurora-desktop ~/.local/bin/aurora-desktop
chmod +x ~/.local/bin/aurora-desktop
cp aurora-desktop.png ~/.local/share/icons/hicolor/512x512/apps/aurora-desktop.png
cp aurora-desktop.png ~/.local/share/pixmaps/aurora-desktop.png

cat << 'DESK' > ~/.local/share/applications/aurora-desktop.desktop
[Desktop Entry]
Version=1.0
Name=AURORA IDM
GenericName=Internet Download Manager
Comment=Ultra-High Performance Internet Download Manager (React 19 + Tauri 2.0)
Exec=aurora-desktop %U
Icon=aurora-desktop
Terminal=false
Type=Application
Categories=Network;FileTransfer;Utility;
MimeType=x-scheme-handler/aurora;x-scheme-handler/auroradl;
Keywords=download;manager;accelerator;idm;aurora;kaushal;
StartupWMClass=aurora-desktop
StartupNotify=true
DESK

which update-desktop-database >/dev/null 2>&1 && update-desktop-database ~/.local/share/applications 2>/dev/null || true
which gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f ~/.local/share/icons/hicolor 2>/dev/null || true
which xdg-mime >/dev/null 2>&1 && xdg-mime default aurora-desktop.desktop x-scheme-handler/aurora x-scheme-handler/auroradl 2>/dev/null || true
echo "✅ AURORA IDM (React 19 + Tauri 2.0) installed successfully!"
