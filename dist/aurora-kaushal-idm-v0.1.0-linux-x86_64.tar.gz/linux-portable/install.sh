#!/usr/bin/env bash
set -e
echo "Installing AURORA Kaushal IDM to ~/.local/bin..."
killall -9 aurora-gui 2>/dev/null || true
mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications
mkdir -p ~/.local/share/icons/hicolor/128x128/apps

cp aurora-gui ~/.local/bin/aurora-gui
chmod +x ~/.local/bin/aurora-gui
cp aurora-icon.png ~/.local/share/icons/hicolor/128x128/apps/aurora-idm.png

cat << 'DESK' > ~/.local/share/applications/aurora-idm.desktop
[Desktop Entry]
Name=AURORA Kaushal IDM
Comment=Next-Gen High-Speed Download Accelerator
Exec=aurora-gui %U
Icon=aurora-idm
Terminal=false
Type=Application
Categories=Network;FileTransfer;
DESK

which update-desktop-database >/dev/null 2>&1 && update-desktop-database ~/.local/share/applications || true
echo "✅ AURORA Kaushal IDM installed successfully!"
