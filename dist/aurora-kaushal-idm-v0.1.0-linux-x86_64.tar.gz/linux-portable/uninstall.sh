#!/usr/bin/env bash
set -e
echo "Uninstalling AURORA Kaushal IDM..."
killall -9 aurora-gui 2>/dev/null || true
rm -f ~/.local/bin/aurora-gui
rm -f ~/.local/share/applications/aurora-idm.desktop
rm -f ~/.local/share/icons/hicolor/128x128/apps/aurora-idm.png
which update-desktop-database >/dev/null 2>&1 && update-desktop-database ~/.local/share/applications || true
echo "✅ AURORA Kaushal IDM completely removed."
