@echo off
title AURORA IDM Setup
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\AuroraIDM"

echo ========================================================
echo  AURORA Kaushal IDM - High-Speed Download Manager Setup
echo ========================================================
echo [1/4] Terminating existing running instances...
taskkill /F /IM aurora-desktop.exe 2>nul
taskkill /F /IM aurora-gui.exe 2>nul
timeout /t 1 /nobreak >nul

echo [2/4] Cleaning previous installation...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
mkdir "%INSTALL_DIR%"

echo [3/4] Copying application files, WebView2 dependencies, and icons...
copy /y "%~dp0aurora-desktop.exe" "%INSTALL_DIR%\" >nul
copy /y "%~dp0WebView2Loader.dll" "%INSTALL_DIR%\" >nul 2>nul
copy /y "%~dp0icon.ico" "%INSTALL_DIR%\" >nul 2>nul
copy /y "%~dp0icon.png" "%INSTALL_DIR%\" >nul 2>nul
copy /y "%~dp0uninstall.bat" "%INSTALL_DIR%\" >nul

echo [4/4] Creating Desktop and Start Menu shortcuts with icon...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desk = [System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'AURORA IDM.lnk'); " ^
  "$s = $ws.CreateShortcut($desk); " ^
  "$s.TargetPath = '%INSTALL_DIR%\aurora-desktop.exe'; " ^
  "$s.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$s.IconLocation = '%INSTALL_DIR%\icon.ico,0'; " ^
  "$s.Save(); " ^
  "$startDir = [System.IO.Path]::Combine([Environment]::GetFolderPath('Programs'), 'AURORA IDM'); " ^
  "if (!(Test-Path $startDir)) { New-Item -ItemType Directory -Path $startDir | Out-Null }; " ^
  "$s2 = $ws.CreateShortcut([System.IO.Path]::Combine($startDir, 'AURORA IDM.lnk')); " ^
  "$s2.TargetPath = '%INSTALL_DIR%\aurora-desktop.exe'; " ^
  "$s2.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$s2.IconLocation = '%INSTALL_DIR%\icon.ico,0'; " ^
  "$s2.Save()"

echo.
echo ========================================================
echo  SUCCESS: AURORA IDM installed successfully!
echo  Launching application...
echo ========================================================
start "" "%INSTALL_DIR%\aurora-desktop.exe"
timeout /t 2 /nobreak >nul
exit
