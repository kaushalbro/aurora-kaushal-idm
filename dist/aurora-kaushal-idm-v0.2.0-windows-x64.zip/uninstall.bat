@echo off
title AURORA IDM Uninstaller
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\AuroraIDM"

echo ========================================================
echo  AURORA IDM - Uninstaller
echo ========================================================
echo [1/2] Terminating running aurora-gui.exe instances...
taskkill /F /IM aurora-gui.exe 2>nul
timeout /t 1 /nobreak >nul

echo [2/2] Deleting application files, cache, and shortcuts...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
del /f /q "%USERPROFILE%\Desktop\AURORA IDM.lnk" 2>nul
del /f /q "%USERPROFILE%\Desktop\AURORA Kaushal IDM.lnk" 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\AURORA IDM" 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\AURORA Kaushal IDM" 2>nul

echo.
echo ========================================================
echo  AURORA IDM has been completely removed.
echo ========================================================
pause
