#!/usr/bin/env bash
set -e
echo "Installing AURORA IDM to ~/.local/bin..."
killall -9 aurora-gui 2>/dev/null || true
killall -9 aurora-desktop 2>/dev/null || true

# Remove any old stale launchers
rm -f ~/.local/share/applications/com.aurora.kaushal.idm.desktop 2>/dev/null || true
rm -f ~/.local/share/applications/aurora-desktop.desktop 2>/dev/null || true

mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications
mkdir -p ~/.local/share/icons/hicolor/128x128/apps
mkdir -p ~/.local/share/pixmaps

cp aurora-gui ~/.local/bin/aurora-gui
chmod +x ~/.local/bin/aurora-gui
cp aurora-icon.png ~/.local/share/icons/hicolor/128x128/apps/aurora-idm.png
cp aurora-icon.png ~/.local/share/pixmaps/aurora-idm.png

cat << 'DESK' > ~/.local/share/applications/aurora-idm.desktop
[Desktop Entry]
Version=1.0
Name=AURORA IDM
GenericName=Internet Download Manager
Comment=Ultra-High Performance Internet Download Manager built in Rust
Exec=aurora-gui %U
Icon=aurora-idm
Terminal=false
Type=Application
Categories=Network;FileTransfer;Utility;
MimeType=x-scheme-handler/aurora;
Keywords=download;manager;accelerator;idm;aurora;kaushal;
StartupWMClass=aurora-gui
StartupNotify=true
DESK

which update-desktop-database >/dev/null 2>&1 && update-desktop-database ~/.local/share/applications 2>/dev/null || true
which gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f ~/.local/share/icons/hicolor 2>/dev/null || true
echo "✅ AURORA IDM installed successfully!"
