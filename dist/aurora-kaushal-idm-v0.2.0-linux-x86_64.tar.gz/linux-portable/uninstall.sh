#!/usr/bin/env bash
set -e
echo "Uninstalling AURORA IDM..."
killall -9 aurora-gui 2>/dev/null || true
killall -9 aurora-desktop 2>/dev/null || true
rm -f ~/.local/bin/aurora-gui
rm -f ~/.local/share/applications/aurora-idm.desktop
rm -f ~/.local/share/applications/com.aurora.kaushal.idm.desktop 2>/dev/null || true
rm -f ~/.local/share/applications/aurora-desktop.desktop 2>/dev/null || true
rm -f ~/.local/share/icons/hicolor/128x128/apps/aurora-idm.png
rm -f ~/.local/share/pixmaps/aurora-idm.png
which update-desktop-database >/dev/null 2>&1 && update-desktop-database ~/.local/share/applications 2>/dev/null || true
which gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f ~/.local/share/icons/hicolor 2>/dev/null || true
echo "✅ AURORA IDM completely removed."
